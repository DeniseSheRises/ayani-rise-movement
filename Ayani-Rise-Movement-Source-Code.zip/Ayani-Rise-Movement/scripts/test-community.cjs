// Exercises the actual route handlers against isolated D1 and R2 bindings.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const root = path.resolve(__dirname, '..');
const ts = require(path.join(root, 'node_modules/typescript'));
const miniflareDir = fs.readdirSync(path.join(root, 'node_modules/.pnpm')).find(name => name.startsWith('miniflare@'));
const { Miniflare } = require(path.join(root, 'node_modules/.pnpm', miniflareDir, 'node_modules/miniflare'));
let bindings;
let identityHeaders = new Headers();
const originalLoad = Module._load;
Module._load = function(name, parent, isMain) {
  if (name === 'cloudflare:workers') return { env: bindings };
  if (name === 'next/headers') return { headers: async () => identityHeaders };
  return originalLoad.call(this, name, parent, isMain);
};
for (const extension of ['.ts', '.tsx']) require.extensions[extension] = (module, file) => {
  const code = ts.transpileModule(fs.readFileSync(file, 'utf8'), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX, esModuleInterop: true } }).outputText;
  module._compile(code, file);
};
const origin = 'https://community-test.example';
function identity(kind) {
  identityHeaders = new Headers();
  if (kind !== 'guest') {
    identityHeaders.set('oai-authenticated-user-id', kind === 'owner' ? 'owner-site-id' : kind);
    identityHeaders.set('oai-authenticated-user-email', kind === 'owner' ? 'denise.en24@gmail.com' : `${kind}@example.test`);
  }
}
function jsonRequest(body, route = '/api/community', requestOrigin = origin) {
  return new Request(origin + route, { method: 'POST', headers: { 'Content-Type': 'application/json', Origin: requestOrigin }, body: JSON.stringify(body) });
}
async function status(response, expected) {
  assert.equal(response.status, expected, `Expected ${expected}; got ${response.status}: ${response.status >= 400 ? await response.clone().text() : ''}`);
  return response;
}

(async () => {
  const mf = new Miniflare({ modules: true, script: 'export default { fetch() { return new Response("test"); } }', compatibilityDate: '2026-05-15', d1Databases: { DB: 'community-test' }, r2Buckets: { BUCKET: 'community-test' } });
  try {
    bindings = await mf.getBindings();
    for (const statement of fs.readFileSync(path.join(root, 'drizzle/0000_organic_viper.sql'), 'utf8').split('--> statement-breakpoint')) {
      if (statement.trim()) await bindings.DB.prepare(statement.trim()).run();
    }
    const routes = require(path.join(root, 'app/api/community/route.ts'));
    const uploads = require(path.join(root, 'app/api/community/uploads/route.ts'));
    const files = require(path.join(root, 'app/api/community/files/[id]/route.ts'));
    const context = id => ({ params: Promise.resolve({ id }) });
    const getFile = (id, range) => files.GET(new Request(`${origin}/api/community/files/${id}`, { headers: range ? { Range: range } : {} }), context(id));

    identity('guest');
    const guestData = await (await routes.GET()).json();
    assert.equal(guestData.status, 'guest'); assert.deepEqual(guestData.resources, []); assert.deepEqual(guestData.calls, []); assert.deepEqual(guestData.members, []);
    await status(await routes.POST(jsonRequest({ action: 'request-access' })), 401);
    await status(await getFile('anything'), 401);

    identity('sister');
    await status(await routes.POST(jsonRequest({ action: 'request-access', status: 'active', userId: 'owner-site-id' })), 200);
    assert.equal((await (await routes.GET()).json()).status, 'pending');
    await status(await getFile('anything'), 403);
    await status(await routes.POST(jsonRequest({ action: 'member-status', id: 'sister', status: 'active' })), 403);
    await status(await routes.POST(jsonRequest({ action: 'request-access' }, '/api/community', 'https://other.example')), 403);
    await status(await uploads.POST(jsonRequest({ action: 'start' })), 403);

    identity('owner');
    const ownerData = await (await routes.GET()).json();
    assert.equal(ownerData.isAdmin, true); assert.equal(ownerData.members.length, 1);
    await status(await routes.POST(jsonRequest({ action: 'member-status', id: 'sister', status: 'active' })), 200);
    await status(await routes.POST(jsonRequest({ action: 'save-call', title: 'Test circle', description: '', startsAt: '2027-01-02T18:00:00Z', durationMinutes: 60, meetUrl: 'https://evil.example/abc-defg-hij' })), 400);
    await status(await routes.POST(jsonRequest({ action: 'save-call', title: 'Test circle', description: 'A test invitation.', startsAt: '2027-01-02T18:00:00Z', durationMinutes: 60, meetUrl: 'https://meet.google.com/abc-defg-hij' })), 200);

    const pdf = new TextEncoder().encode('%PDF-1.4\nMember-only test document.\n%%EOF');
    const startResponse = await uploads.POST(jsonRequest({ action: 'start', title: 'A reflection', description: 'Protected PDF.', kind: 'pdf', category: 'Embodiment', fileName: 'reflection.pdf', sizeBytes: pdf.length }));
    await status(startResponse, 200); const start = await startResponse.json();
    await status(await uploads.POST(jsonRequest({ action: 'complete', id: start.id })), 400);
    await status(await uploads.PUT(new Request(`${origin}/api/community/uploads?id=${start.id}&part=2`, { method: 'PUT', headers: { Origin: origin }, body: pdf })), 400);
    await status(await uploads.PUT(new Request(`${origin}/api/community/uploads?id=${start.id}&part=1`, { method: 'PUT', headers: { Origin: origin }, body: pdf })), 200);
    await status(await uploads.POST(jsonRequest({ action: 'complete', id: start.id })), 200);
    await status(await uploads.POST(jsonRequest({ action: 'complete', id: start.id })), 200);
    assert.equal(await bindings.DB.prepare('SELECT count(*) AS count FROM community_uploads').first('count'), 0);

    identity('sister');
    const approved = await (await routes.GET()).json();
    assert.equal(approved.status, 'active'); assert.equal(approved.resources.length, 1); assert.equal(approved.calls.length, 1); assert.deepEqual(approved.members, []);
    assert.equal(approved.resources[0].file_key, undefined);
    const download = await getFile(start.id); await status(download, 200);
    assert.match(download.headers.get('Content-Disposition'), /^attachment/); assert.match(download.headers.get('Cache-Control'), /no-store/);
    assert.deepEqual(new Uint8Array(await download.arrayBuffer()), pdf);
    const partial = await getFile(start.id, 'bytes=0-7'); await status(partial, 206);
    assert.equal(partial.headers.get('Content-Range'), `bytes 0-7/${pdf.length}`); assert.equal((await partial.arrayBuffer()).byteLength, 8);
    await status(await getFile(start.id, 'bytes=999999-'), 416);
    await status(await getFile(start.id, 'bytes=0-1,3-4'), 416);

    identity('owner');
    await status(await routes.POST(jsonRequest({ action: 'resource-visibility', id: start.id, published: false })), 200);
    identity('sister');
    assert.equal((await (await routes.GET()).json()).resources.length, 0);
    await status(await getFile(start.id), 404);
    identity('owner'); await status(await getFile(start.id), 200);
    await status(await routes.POST(jsonRequest({ action: 'resource-visibility', id: start.id, published: true })), 200);
    await status(await routes.POST(jsonRequest({ action: 'member-status', id: 'sister', status: 'paused' })), 200);
    identity('sister'); await status(await getFile(start.id), 403);
    await status(await routes.POST(jsonRequest({ action: 'request-access' })), 200);
    assert.equal((await (await routes.GET()).json()).status, 'paused');
    identity('stranger'); await status(await getFile(start.id), 403);

    identity('owner');
    const video = new Uint8Array(8 * 1024 * 1024 + 20); video.fill(7);
    const videoStartResponse = await uploads.POST(jsonRequest({ action: 'start', title: 'Test recording', description: '', kind: 'recording', category: 'Sisterhood', fileName: 'call.mp4', sizeBytes: video.length }));
    const videoStart = await videoStartResponse.json();
    for (let index = 0; index < 2; index++) {
      await status(await uploads.PUT(new Request(`${origin}/api/community/uploads?id=${videoStart.id}&part=${index + 1}`, { method: 'PUT', headers: { Origin: origin }, body: video.slice(index * videoStart.chunkSize, Math.min((index + 1) * videoStart.chunkSize, video.length)) })), 200);
    }
    await status(await uploads.POST(jsonRequest({ action: 'complete', id: videoStart.id })), 200);
    const videoRange = await getFile(videoStart.id, 'bytes=8388600-8388610'); await status(videoRange, 206);
    assert.equal(videoRange.headers.get('Content-Type'), 'video/mp4'); assert.deepEqual(new Uint8Array(await videoRange.arrayBuffer()), video.slice(8388600, 8388611));
    await status(await routes.POST(jsonRequest({ action: 'delete-resource', id: start.id })), 200);
    await status(await getFile(start.id), 404);

    const React = require(path.join(root, 'node_modules/react'));
    const { renderToStaticMarkup } = require(path.join(root, 'node_modules/react-dom/server'));
    for (const [name, file] of [['home', 'app/page.tsx'], ['community', 'app/community/page.tsx']]) {
      const component = require(path.join(root, file)).default;
      const html = renderToStaticMarkup(React.createElement(component));
      assert.match(html, /Rise Sister/);
      fs.writeFileSync(path.join(root, '.sites-runtime', `${name}-community-qa.html`), html);
    }
    const MemberLibrary = require(path.join(root, 'app/membership/MemberLibrary.tsx')).default;
    for (const kind of ['guest', 'sister', 'owner']) {
      identity(kind);
      const data = await (await routes.GET()).json();
      const html = renderToStaticMarkup(React.createElement(MemberLibrary, { initialData: data, signInPath: '/signin-with-chatgpt?return_to=%2Fmembership', signOutPath: '/signout-with-chatgpt?return_to=%2Fcommunity' }));
      fs.writeFileSync(path.join(root, '.sites-runtime', `${kind}-membership-qa.html`), html);
      if (kind === 'guest') { assert.match(html, /Sign in with ChatGPT/); assert.doesNotMatch(html, /Test recording/); }
      if (kind === 'sister') { assert.match(html, /Let’s reconnect/); assert.doesNotMatch(html, /Test recording/); }
      if (kind === 'owner') { assert.match(html, /Test recording/); assert.match(html, /Add resources/); assert.match(html, /Members/); }
    }
    console.log('Passed: guest restrictions, membership requests and approvals, revocation, owner-only writes, CSRF checks, protected PDF uploads/downloads, multipart recording uploads, byte-range playback, resource visibility/deletion, private API responses, and server rendering.');
  } finally { Module._load = originalLoad; await mf.dispose(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
