import { env } from 'cloudflare:workers';
import { getChatGPTUser, type ChatGPTUser } from '../app/chatgpt-auth';
import { CommunityError } from './community-policy';

// Verified Site owner. Identity is supplied by Sites, never by request JSON.
const ownerEmail = 'denise.en24@gmail.com';
export type Resource = { id: string; title: string; description: string; kind: string; category: string; file_name: string; mime_type: string; file_key: string; size_bytes: number; published: number; created_at: string };
export type LiveCall = { id: string; title: string; description: string; starts_at: string; duration_minutes: number; meet_url: string };
export type Member = { user_id: string; email: string; name: string; status: string; created_at: string };
export type LibraryData = { user: { name: string; email: string } | null; isAdmin: boolean; status: string; resources: Omit<Resource, 'file_key'>[]; calls: LiveCall[]; members: Member[] };

export function db(): D1Database {
  if (!env.DB) throw new CommunityError(503, 'The member library is being prepared. Please try again shortly.');
  return env.DB;
}
export function bucket(): R2Bucket {
  if (!env.BUCKET) throw new CommunityError(503, 'Uploads are being prepared. Please try again shortly.');
  return env.BUCKET;
}
export function isAdmin(user: ChatGPTUser | null): boolean { return user?.email.toLowerCase() === ownerEmail; }
export async function requireUser(): Promise<ChatGPTUser> {
  const user = await getChatGPTUser();
  if (!user) throw new CommunityError(401, 'Please sign in to continue.');
  return user;
}
export async function requireAdmin(): Promise<ChatGPTUser> {
  const user = await requireUser();
  if (!isAdmin(user)) throw new CommunityError(403, 'Only Denisa can manage this community.');
  return user;
}
export async function requireMember(): Promise<ChatGPTUser> {
  const user = await requireUser();
  if (!isAdmin(user)) {
    const member = await db().prepare('SELECT status FROM community_members WHERE user_id = ?').bind(user.userId).first<{ status: string }>();
    if (member?.status !== 'active') throw new CommunityError(403, 'Your membership must be approved before you can open the library.');
  }
  return user;
}
export async function libraryData(): Promise<LibraryData> {
  const user = await getChatGPTUser();
  const admin = isAdmin(user);
  const result: LibraryData = { user: user ? { name: user.fullName || user.displayName, email: user.email } : null, isAdmin: admin, status: 'guest', resources: [], calls: [], members: [] };
  if (!user) return result;
  const member = admin ? null : await db().prepare('SELECT status FROM community_members WHERE user_id = ?').bind(user.userId).first<{ status: string }>();
  result.status = admin ? 'active' : member?.status || 'new';
  if (result.status !== 'active') return result;
  const [resources, calls, members] = await Promise.all([
    db().prepare(`SELECT id,title,description,kind,category,file_name,mime_type,size_bytes,published,created_at FROM community_resources ${admin ? '' : 'WHERE published = 1'} ORDER BY created_at DESC`).all<Omit<Resource, 'file_key'>>(),
    db().prepare('SELECT * FROM community_calls ORDER BY starts_at ASC').all<LiveCall>(),
    admin ? db().prepare('SELECT * FROM community_members ORDER BY created_at DESC').all<Member>() : Promise.resolve({ results: [] as Member[] }),
  ]);
  result.resources = resources.results; result.calls = calls.results; result.members = members.results;
  return result;
}
export const privateHeaders = { 'Cache-Control': 'private, no-store', 'X-Content-Type-Options': 'nosniff' };
export function apiError(error: unknown) {
  if (error instanceof CommunityError) return Response.json({ error: error.message }, { status: error.status, headers: privateHeaders });
  console.error('Community operation failed', error instanceof Error ? error.message : 'Unknown error');
  return Response.json({ error: 'Something went wrong. Please try again.' }, { status: 500, headers: privateHeaders });
}
export async function jsonBody(request: Request): Promise<Record<string, unknown>> {
  if (!request.headers.get('content-type')?.includes('application/json')) throw new CommunityError(415, 'Please send a valid form.');
  const text = await request.text();
  if (text.length > 20000) throw new CommunityError(413, 'This form is too long.');
  try {
    const parsed = JSON.parse(text);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error();
    return parsed;
  } catch { throw new CommunityError(400, 'Please check the form and try again.'); }
}
