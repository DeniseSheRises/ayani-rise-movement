export const CHUNK_SIZE = 8 * 1024 * 1024;
export const MAX_UPLOAD_SIZE = 2 * 1024 * 1024 * 1024;
export const categories = ['Embodiment', 'Dance & expression', 'Ceremony & ritual', 'Sisterhood'] as const;
export type ResourceKind = 'recording' | 'pdf' | 'audio';
export type MemberStatus = 'pending' | 'active' | 'paused';

export class CommunityError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

export function textField(value: unknown, name: string, max: number, required = true): string {
  if (typeof value !== 'string') throw new CommunityError(400, `Please enter ${name}.`);
  const text = value.trim();
  if ((required && !text) || text.length > max) throw new CommunityError(400, `Please check ${name}.`);
  return text;
}

export function meetLink(value: unknown): string {
  const text = textField(value, 'a Google Meet link', 300);
  let url: URL;
  try { url = new URL(text); } catch { throw new CommunityError(400, 'Please use a valid Google Meet link.'); }
  if (url.protocol !== 'https:' || url.hostname !== 'meet.google.com' || url.username || url.password || url.port || !/^\/[a-z]{3}-[a-z]{4}-[a-z]{3}$/.test(url.pathname)) {
    throw new CommunityError(400, 'Please use a meeting link like https://meet.google.com/abc-defg-hij.');
  }
  return url.origin + url.pathname;
}

export function fileDetails(name: unknown, kind: unknown, size: unknown) {
  const fileName = textField(name, 'a filename', 240);
  if (!Number.isSafeInteger(size) || (size as number) <= 0 || (size as number) > MAX_UPLOAD_SIZE) throw new CommunityError(400, 'Choose a file smaller than 2 GB.');
  const extension = fileName.split('.').pop()?.toLowerCase();
  const allowed: Record<string, Record<string, string>> = {
    recording: { mp4: 'video/mp4', webm: 'video/webm' },
    pdf: { pdf: 'application/pdf' },
    audio: { mp3: 'audio/mpeg', m4a: 'audio/mp4', wav: 'audio/wav' },
  };
  const mimeType = typeof kind === 'string' && extension ? allowed[kind]?.[extension] : undefined;
  if (!mimeType) throw new CommunityError(400, 'Choose MP4 or WebM for recordings, PDF for guides, or MP3, M4A or WAV for audio.');
  if (kind === 'pdf' && (size as number) > 50 * 1024 * 1024) throw new CommunityError(400, 'PDFs must be smaller than 50 MB.');
  return { fileName, kind: kind as ResourceKind, sizeBytes: size as number, mimeType };
}

export function checkOrigin(request: Request) {
  if (request.headers.get('sec-fetch-site') === 'cross-site' || request.headers.get('origin') !== new URL(request.url).origin) {
    throw new CommunityError(403, 'Please submit this from the member area.');
  }
}

export function byteRange(value: string | null, size: number): { offset: number; length: number } | null {
  if (!value) return null;
  const match = /^bytes=(\d*)-(\d*)$/.exec(value);
  if (!match || (!match[1] && !match[2])) throw new CommunityError(416, 'Invalid file range.');
  let start: number, end: number;
  if (!match[1]) {
    const suffix = Number(match[2]);
    if (!Number.isSafeInteger(suffix) || suffix <= 0) throw new CommunityError(416, 'Invalid file range.');
    start = Math.max(0, size - suffix); end = size - 1;
  } else {
    start = Number(match[1]); end = match[2] ? Math.min(Number(match[2]), size - 1) : size - 1;
  }
  if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start < 0 || start >= size || end < start) throw new CommunityError(416, 'Invalid file range.');
  return { offset: start, length: end - start + 1 };
}
