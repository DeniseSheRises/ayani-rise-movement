import { integer, primaryKey, sqliteTable, text } from 'drizzle-orm/sqlite-core';

export const communityMembers = sqliteTable('community_members', {
  userId: text('user_id').primaryKey(),
  email: text('email').notNull(),
  name: text('name').notNull(),
  status: text('status').notNull().default('pending'),
  createdAt: text('created_at').notNull(),
});

export const communityResources = sqliteTable('community_resources', {
  id: text('id').primaryKey(),
  title: text('title').notNull(),
  description: text('description').notNull(),
  kind: text('kind').notNull(),
  category: text('category').notNull(),
  fileName: text('file_name').notNull(),
  mimeType: text('mime_type').notNull(),
  fileKey: text('file_key').notNull(),
  sizeBytes: integer('size_bytes').notNull(),
  published: integer('published').notNull().default(1),
  createdAt: text('created_at').notNull(),
});

export const communityCalls = sqliteTable('community_calls', {
  id: text('id').primaryKey(),
  title: text('title').notNull(),
  description: text('description').notNull(),
  startsAt: text('starts_at').notNull(),
  durationMinutes: integer('duration_minutes').notNull(),
  meetUrl: text('meet_url').notNull(),
});

export const communityUploads = sqliteTable('community_uploads', {
  id: text('id').primaryKey(),
  uploadId: text('upload_id').notNull(),
  fileKey: text('file_key').notNull(),
  title: text('title').notNull(),
  description: text('description').notNull(),
  kind: text('kind').notNull(),
  category: text('category').notNull(),
  fileName: text('file_name').notNull(),
  mimeType: text('mime_type').notNull(),
  sizeBytes: integer('size_bytes').notNull(),
  createdAt: text('created_at').notNull(),
});

export const communityUploadParts = sqliteTable('community_upload_parts', {
  uploadId: text('upload_id').notNull(),
  partNumber: integer('part_number').notNull(),
  etag: text('etag').notNull(),
}, table => [primaryKey({ columns: [table.uploadId, table.partNumber] })]);
