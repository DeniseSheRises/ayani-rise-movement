# Ayani Rise Movement — source code export

Exported October 21, 2026.
Website: https://ayanirisemovement.com
Source commit: 96d90c109a6f8c3b74e7110ded6ae4eebe24d149

This ZIP contains the main website's tracked source files: pages, styles,
components, bundled images, membership/API code, database schema/migrations,
build configuration, package manifest, and dependency lockfile.

## Run locally

1. Install Node.js 22.13 or newer and pnpm 11.25.0 (the version in package.json).
2. Open a terminal in this extracted folder.
3. Run `pnpm install --frozen-lockfile`.
4. Run `pnpm dev`, then open http://localhost:5173.

The existing README.md contains framework and local development notes.
This is a React/TypeScript project using Vinext, Vite, and Cloudflare Workers.

## Membership and hosting

The hosted membership uses Cloudflare D1 for records, R2 for uploaded content,
and ChatGPT Sites sign-in. The source and schema are included; live database
records, uploaded recordings/PDFs, credentials, and hosting accounts are not.
Moving the membership to another host requires configuring equivalent storage
and authentication. This ZIP is a source export, not an automatic Vercel migration.

Bundled assets are included. Assets referenced by external URLs remain external.
Dependencies, build output, local runtime state, and Git history are omitted.

## Separate Return to Her retreat website

The main site's /return-to-her page redirects to:
https://return-to-her-1.vercel.app

The current retreat website is a separate project; its latest source is at:
https://github.com/DeniseSheRises/return-to-her-1

To export that project, sign in to GitHub and choose Code > Download ZIP,
or open https://github.com/DeniseSheRises/return-to-her-1/archive/refs/heads/main.zip
The older supporting retreat components retained here are not the current
standalone retreat website.
