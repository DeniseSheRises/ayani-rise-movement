import type { Metadata } from 'next';
import HubNav from '../HubNav';
export const metadata: Metadata = { title: 'Rise Sister Online | Ayani Rise Movement', description: 'An online home for feminine embodiment and sisterhood. Live Google Meet gatherings, a private recording library, and practices to return to.' };
export default function CommunityPage() {
  return <div className="hub community-page">
    <HubNav />
    <main>
      <section className="community-hero hub-section">
        <div><p className="hub-eyebrow">AYANI RISE SISTERHOOD · ONLINE</p><h1>Rise Sister.<br/><em>Wherever you are.</em></h1><p className="community-intro">A space to come back to your body, connect with other women, and carry the feeling of sisterhood into your everyday life.</p><div className="hub-actions"><a className="hub-button" href="/membership">Enter the community <span aria-hidden="true">↗</span></a><a className="hub-text-link" href="#inside">What’s inside <span aria-hidden="true">↓</span></a></div><p className="community-footnote">The founding community is taking shape. Request access and Denisa will welcome you in.</p></div>
        <div className="community-orbit" aria-hidden="true"><div className="community-orbit-ring"/><span>Move.<br/>Feel.<br/><em>Belong.</em></span><p>A LITTLE CLOSER<br/>TO YOURSELF.</p></div>
      </section>
      <section className="community-inside hub-section" id="inside"><div className="hub-section-heading"><div><p className="hub-eyebrow">A HOME TO RETURN TO</p><h2>Stay close to<br/><em>what moves you.</em></h2></div><p>You can join us live, revisit a recording, or make space for a practice in your own time.</p></div><div className="community-benefits"><article><span>01 / GATHER LIVE</span><h3>A circle,<br/><em>beyond distance.</em></h3><p>Live calls on Google Meet, with a weekly or biweekly rhythm to be confirmed. Space for movement, ceremony, reflection, and connection.</p></article><article><span>02 / RETURN IN YOUR OWN TIME</span><h3>Your practice.<br/><em>Your pace.</em></h3><p>A private library of uploaded call recordings and guided practices. Come back to the moments and movements that speak to you.</p></article><article><span>03 / TAKE IT INTO YOUR LIFE</span><h3>Small rituals.<br/><em>Lasting connection.</em></h3><p>Downloadable PDFs, reflection prompts, and resources to support your practice between our gatherings.</p></article></div></section>
      <section className="community-invitation hub-section"><p className="hub-eyebrow">YOU DON’T HAVE TO DO IT ALONE</p><h2>A place to be <em>you.</em></h2><p>The library is beginning. Call dates and new resources will appear in your member area as Denisa adds them.</p><a className="hub-button hub-button-light" href="/membership">Visit the member area <span aria-hidden="true">↗</span></a><p className="community-small">Sign in with ChatGPT, then request access. Membership approval is managed by Denisa.</p></section>
    </main>
    <footer className="community-footer"><a href="/">← Back to Ayani Rise Movement</a><a href="https://www.instagram.com/denisawild_/" target="_blank" rel="noreferrer">Connect with Denisa ↗</a></footer>
  </div>;
}
