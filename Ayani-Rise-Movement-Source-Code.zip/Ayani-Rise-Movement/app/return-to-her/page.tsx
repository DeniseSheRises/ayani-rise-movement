import { redirect } from "next/navigation";

export default function ReturnToHer() {
  redirect("https://return-to-her-1.vercel.app");
}
