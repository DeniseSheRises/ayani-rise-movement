"use client";

import { useEffect } from "react";

const revealSelector = [
  ".section-intro",
  ".place-heading",
  ".feel-header",
  ".for-you-heading",
  ".for-you-grid article",
  ".for-you-close",
  ".practice-groups article",
  ".experience-grid article",
  ".room-grid details",
  ".tile",
  ".embodiment > *",
  ".hosts-heading",
  ".host-list article",
  ".faq-heading",
  ".accordion details",
  ".waitlist-nudge > *",
  ".waitlist > *",
].join(",");

export default function RevealEffects() {
  useEffect(() => {
    const root = document.documentElement;
    const reducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches;
    const items = Array.from(
      document.querySelectorAll<HTMLElement>(revealSelector),
    );

    const updateProgress = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      const progress = max > 0 ? Math.min(1, window.scrollY / max) : 0;
      root.style.setProperty("--page-progress", String(progress));
    };

    updateProgress();
    window.addEventListener("scroll", updateProgress, { passive: true });
    window.addEventListener("resize", updateProgress);

    if (reducedMotion) {
      items.forEach((item) => item.classList.add("is-visible"));
      return () => {
        window.removeEventListener("scroll", updateProgress);
        window.removeEventListener("resize", updateProgress);
      };
    }

    root.classList.add("motion-ready");
    items.forEach((item, index) => {
      item.classList.add("scroll-reveal");
      item.style.setProperty("--reveal-delay", `${(index % 3) * 80}ms`);
    });

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.14, rootMargin: "0px 0px -8%" },
    );

    items.forEach((item) => observer.observe(item));

    return () => {
      observer.disconnect();
      root.classList.remove("motion-ready");
      window.removeEventListener("scroll", updateProgress);
      window.removeEventListener("resize", updateProgress);
    };
  }, []);

  return <div className="scroll-progress" aria-hidden="true" />;
}

