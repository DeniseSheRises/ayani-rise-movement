"use client";

import { useEffect, useRef, useState } from "react";

const practiceGroups = [
  {
    number: "01",
    title: "Embodiment",
    items: [
      "Dance & Somatic Movement",
      "Kundalini Activation",
      "Yoga",
      "Breathwork",
      "Feminine Embodiment",
    ],
  },
  {
    number: "02",
    title: "Connection",
    items: [
      "Sisterhood",
      "Authentic Relating",
      "Sound Healing",
      "Reiki & Healing Touch",
      "Rest & Play",
    ],
  },
  {
    number: "03",
    title: "Integration",
    items: [
      "Ceremonies & Rituals",
      "Nervous System Practices",
      "Nature Immersion",
      "Plant Medicine",
      "Deep Inner Exploration",
    ],
  },
];

export default function SacredPracticesAccordion() {
  const rootRef = useRef<HTMLDivElement>(null);
  const [openGroups, setOpenGroups] = useState<Set<number>>(new Set());

  useEffect(() => {
    const root = rootRef.current;
    if (!root) return;

    const reducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches;

    if (reducedMotion) {
      const revealAll = window.setTimeout(() => {
        setOpenGroups(new Set(practiceGroups.map((_, index) => index)));
      }, 0);
      return () => window.clearTimeout(revealAll);
    }

    const timers: number[] = [];
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (!entry.isIntersecting || entry.intersectionRatio < 0.72) return;

        practiceGroups.forEach((_, index) => {
          timers.push(
            window.setTimeout(() => {
              setOpenGroups((current) => new Set([...current, index]));
            }, index * 180),
          );
        });
        observer.unobserve(root);
      },
      { threshold: [0.5, 0.72, 0.9] },
    );

    observer.observe(root);
    return () => {
      observer.disconnect();
      timers.forEach((timer) => window.clearTimeout(timer));
    };
  }, []);

  const toggleGroup = (index: number) => {
    setOpenGroups((current) => {
      const next = new Set(current);
      if (next.has(index)) next.delete(index);
      else next.add(index);
      return next;
    });
  };

  return (
    <div className="practice-groups" ref={rootRef}>
      {practiceGroups.map((group, index) => {
        const isOpen = openGroups.has(index);
        const panelId = `practice-panel-${index + 1}`;

        return (
          <article className={isOpen ? "is-open" : ""} key={group.title}>
            <button
              className="practice-summary"
              type="button"
              aria-expanded={isOpen}
              aria-controls={panelId}
              onClick={() => toggleGroup(index)}
            >
              <span className="practice-number">{group.number}</span>
              <h3>{group.title}</h3>
              <span className="practice-toggle" aria-hidden="true">
                {isOpen ? "−" : "+"}
              </span>
            </button>
            <div
              className="practice-panel"
              id={panelId}
              aria-hidden={!isOpen}
            >
              <div>
                <ul>
                  {group.items.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </div>
            </div>
          </article>
        );
      })}
    </div>
  );
}

