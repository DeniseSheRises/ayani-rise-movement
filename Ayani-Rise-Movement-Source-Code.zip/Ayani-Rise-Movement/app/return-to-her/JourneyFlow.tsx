"use client";

import { useEffect, useRef } from "react";

const steps = [
  {
    title: "Awaken",
    copy: "Become aware of the patterns, expectations and ways of living that may no longer feel true to you.",
  },
  {
    title: "Release",
    copy: "Create space to release old beliefs, fears, emotions and versions of yourself you’re ready to leave behind.",
  },
  {
    title: "Remember",
    copy: "Reconnect with your body, desires, intuition, voice and the woman underneath all the conditioning.",
  },
  {
    title: "Rise",
    copy: "Begin choosing yourself with greater courage, self-trust and confidence.",
  },
  {
    title: "Expand",
    copy: "Open to new possibilities — new ways of living, relating, expressing and creating your life.",
  },
  {
    title: "Embody",
    copy: "Move beyond knowing who you want to be and begin feeling, expressing and living her through your body.",
  },
];

export default function JourneyFlow() {
  const flowRef = useRef<HTMLDivElement>(null);
  const pathRef = useRef<SVGPathElement>(null);

  useEffect(() => {
    const flow = flowRef.current;
    const path = pathRef.current;
    if (!flow || !path) return;

    const reducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches;

    const items = Array.from(flow.querySelectorAll<HTMLElement>(".flow-step"));
    if (reducedMotion) {
      items.forEach((item) => item.classList.add("is-visible"));
      path.style.strokeDashoffset = "0";
      return;
    }

    flow.classList.add("is-enhanced");

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.38, rootMargin: "0px 0px -8%" },
    );

    items.forEach((item) => observer.observe(item));

    let frame = 0;
    const drawPath = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const rect = flow.getBoundingClientRect();
        const viewport = window.innerHeight;
        const start = viewport * 0.72;
        const distance = rect.height + viewport * 0.28;
        const progress = Math.min(
          1,
          Math.max(0, (start - rect.top) / distance),
        );
        path.style.strokeDashoffset = String(1 - progress);
      });
    };

    drawPath();
    window.addEventListener("scroll", drawPath, { passive: true });
    window.addEventListener("resize", drawPath);

    return () => {
      observer.disconnect();
      cancelAnimationFrame(frame);
      window.removeEventListener("scroll", drawPath);
      window.removeEventListener("resize", drawPath);
    };
  }, []);

  return (
    <div className="journey-flow" ref={flowRef}>
      <svg
        className="flow-line"
        viewBox="0 0 1000 1280"
        preserveAspectRatio="none"
        aria-hidden="true"
      >
        <path
          ref={pathRef}
          pathLength="1"
          d="M500 0 C500 100 280 125 300 240 C320 355 720 340 700 465 C680 590 260 565 285 690 C310 815 740 790 710 920 C680 1050 490 1080 500 1280"
        />
      </svg>
      <ol>
        {steps.map((step, index) => (
          <li className="flow-step" key={step.title}>
            <span className="flow-number">
              {String(index + 1).padStart(2, "0")}
            </span>
            <div className="flow-copy">
              <strong>{step.title}</strong>
              <p>{step.copy}</p>
            </div>
            <span className="flow-orbit" aria-hidden="true" />
          </li>
        ))}
      </ol>
    </div>
  );
}

