'use client';
import {useState} from 'react';
export default function EarlySister(){
  const [copied,setCopied]=useState(false);
  const [message,setMessage]=useState('');
  const copy=async()=>{try {await navigator.clipboard.writeText('RISEFIRST');setCopied(true);setMessage('Code copied. Use it on your individual ticket.');} catch{setMessage('Use code RISEFIRST on your individual ticket.');}};
  return <div className="hub-early"><div><strong>Early Sister Special</strong><p>$5 off your individual ticket until October 20.</p></div><button type="button" onClick={copy} aria-label="Copy early sister discount code RISEFIRST">{copied?'Copied ✓':'RISEFIRST'} <span aria-hidden="true">{copied?'':'↗'}</span></button><span className="hub-sr-only" role="status">{message}</span></div>;
}
