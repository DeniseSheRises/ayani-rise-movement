import { apiError, bucket, db, isAdmin, privateHeaders, requireMember, type Resource } from '../../../../../lib/community';
import { byteRange, CommunityError } from '../../../../../lib/community-policy';
export const dynamic = 'force-dynamic';
type Context = { params: Promise<{ id: string }> };
async function serve(request: Request, context: Context) {
  try {
    const user = await requireMember();
    const { id } = await context.params;
    const file = await db().prepare('SELECT * FROM community_resources WHERE id = ?').bind(id).first<Resource>();
    if (!file || (!isAdmin(user) && !file.published)) throw new CommunityError(404, 'This resource is not available.');
    const object = await bucket().head(file.file_key);
    if (!object) throw new CommunityError(404, 'This file is not available.');
    let range: { offset: number; length: number } | null;
    try { range = byteRange(request.headers.get('range'), object.size); }
    catch { return new Response(null, { status: 416, headers: { ...privateHeaders, 'Content-Range': `bytes */${object.size}` } }); }
    const headers = new Headers(privateHeaders);
    headers.set('Content-Type', file.mime_type);
    headers.set('Accept-Ranges', 'bytes');
    headers.set('Content-Length', String(range?.length ?? object.size));
    headers.set('Content-Disposition', `${file.kind === 'pdf' ? 'attachment' : 'inline'}; filename*=UTF-8''${encodeURIComponent(file.file_name)}`);
    headers.set('Content-Security-Policy', "default-src 'none'; sandbox");
    if (range) headers.set('Content-Range', `bytes ${range.offset}-${range.offset + range.length - 1}/${object.size}`);
    if (request.method === 'HEAD') return new Response(null, { status: range ? 206 : 200, headers });
    const body = await bucket().get(file.file_key, range ? { range } : undefined);
    if (!body || !('body' in body)) throw new CommunityError(404, 'This file is not available.');
    return new Response(body.body, { status: range ? 206 : 200, headers });
  } catch (error) { return apiError(error); }
}
export const GET = serve;
export const HEAD = serve;
