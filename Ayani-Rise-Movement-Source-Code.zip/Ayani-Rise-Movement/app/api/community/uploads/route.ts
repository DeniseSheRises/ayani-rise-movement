import { apiError, bucket, db, jsonBody, privateHeaders, requireAdmin } from '../../../../lib/community';
import { categories, checkOrigin, CHUNK_SIZE, CommunityError, fileDetails, textField } from '../../../../lib/community-policy';
export const dynamic = 'force-dynamic';
type Upload = { id: string; upload_id: string; file_key: string; title: string; description: string; kind: string; category: string; file_name: string; mime_type: string; size_bytes: number; created_at: string };

async function findUpload(id: string) {
  const upload = await db().prepare('SELECT * FROM community_uploads WHERE id = ?').bind(id).first<Upload>();
  if (!upload) throw new CommunityError(404, 'This upload has expired. Please start again.');
  return upload;
}
export async function POST(request: Request) {
  try {
    checkOrigin(request); await requireAdmin();
    const data = await jsonBody(request);
    if (data.action === 'start') {
      const { fileName, kind, sizeBytes, mimeType } = fileDetails(data.fileName, data.kind, data.sizeBytes);
      const title = textField(data.title, 'a title', 150);
      const description = textField(data.description, 'a description', 1200, false);
      const category = textField(data.category, 'a category', 80);
      if (!(categories as readonly string[]).includes(category)) throw new CommunityError(400, 'Please choose a library category.');
      const id = crypto.randomUUID(); const key = `community/${id}`;
      const upload = await bucket().createMultipartUpload(key, { httpMetadata: { contentType: mimeType } });
      try {
        await db().prepare('INSERT INTO community_uploads (id,upload_id,file_key,title,description,kind,category,file_name,mime_type,size_bytes,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)').bind(id, upload.uploadId, key, title, description, kind, category, fileName, mimeType, sizeBytes, new Date().toISOString()).run();
      } catch (error) { await upload.abort(); throw error; }
      return Response.json({ id, chunkSize: CHUNK_SIZE }, { headers: privateHeaders });
    }
    if (data.action !== 'complete') throw new CommunityError(400, 'Unknown upload action.');
    const id = textField(data.id, 'an upload', 100);
    const existing = await db().prepare('SELECT id FROM community_resources WHERE id = ?').bind(id).first();
    if (existing) return Response.json({ ok: true, id }, { headers: privateHeaders });
    const upload = await findUpload(id);
    const parts = await db().prepare('SELECT part_number,etag FROM community_upload_parts WHERE upload_id = ? ORDER BY part_number').bind(id).all<{ part_number: number; etag: string }>();
    if (parts.results.length !== Math.ceil(upload.size_bytes / CHUNK_SIZE) || parts.results.some((part, index) => part.part_number !== index + 1)) throw new CommunityError(400, 'Some parts are missing. Please restart the upload.');
    let object = await bucket().head(upload.file_key);
    if (!object) object = await bucket().resumeMultipartUpload(upload.file_key, upload.upload_id).complete(parts.results.map(part => ({ partNumber: part.part_number, etag: part.etag })));
    if (object.size !== upload.size_bytes) throw new CommunityError(400, 'The file size did not match. Please restart the upload.');
    await db().batch([
      db().prepare('INSERT INTO community_resources (id,title,description,kind,category,file_name,mime_type,file_key,size_bytes,published,created_at) VALUES (?,?,?,?,?,?,?,?,?,1,?)').bind(id, upload.title, upload.description, upload.kind, upload.category, upload.file_name, upload.mime_type, upload.file_key, upload.size_bytes, upload.created_at),
      db().prepare('DELETE FROM community_upload_parts WHERE upload_id = ?').bind(id),
      db().prepare('DELETE FROM community_uploads WHERE id = ?').bind(id),
    ]);
    return Response.json({ ok: true, id }, { headers: privateHeaders });
  } catch (error) { return apiError(error); }
}
export async function PUT(request: Request) {
  try {
    checkOrigin(request); await requireAdmin();
    const url = new URL(request.url);
    const id = textField(url.searchParams.get('id'), 'an upload', 100);
    const partNumber = Number(url.searchParams.get('part'));
    const upload = await findUpload(id);
    const count = Math.ceil(upload.size_bytes / CHUNK_SIZE);
    if (!Number.isInteger(partNumber) || partNumber < 1 || partNumber > count) throw new CommunityError(400, 'Invalid upload part.');
    const expected = Math.min(CHUNK_SIZE, upload.size_bytes - (partNumber - 1) * CHUNK_SIZE);
    if (Number(request.headers.get('content-length')) > CHUNK_SIZE) throw new CommunityError(413, 'This upload part is too large.');
    const body = await request.arrayBuffer();
    if (body.byteLength !== expected) throw new CommunityError(400, 'The file part did not match. Please restart the upload.');
    const part = await bucket().resumeMultipartUpload(upload.file_key, upload.upload_id).uploadPart(partNumber, body);
    await db().prepare('INSERT INTO community_upload_parts (upload_id,part_number,etag) VALUES (?,?,?) ON CONFLICT(upload_id,part_number) DO UPDATE SET etag = excluded.etag').bind(id, partNumber, part.etag).run();
    return Response.json({ ok: true }, { headers: privateHeaders });
  } catch (error) { return apiError(error); }
}
export async function DELETE(request: Request) {
  try {
    checkOrigin(request); await requireAdmin();
    const id = textField(new URL(request.url).searchParams.get('id'), 'an upload', 100);
    const upload = await findUpload(id);
    const resource = await db().prepare('SELECT id FROM community_resources WHERE id = ?').bind(id).first();
    if (resource) throw new CommunityError(409, 'This upload has already been published.');
    const object = await bucket().head(upload.file_key);
    if (object) await bucket().delete(upload.file_key);
    else await bucket().resumeMultipartUpload(upload.file_key, upload.upload_id).abort();
    await db().batch([db().prepare('DELETE FROM community_upload_parts WHERE upload_id = ?').bind(id), db().prepare('DELETE FROM community_uploads WHERE id = ?').bind(id)]);
    return Response.json({ ok: true }, { headers: privateHeaders });
  } catch (error) { return apiError(error); }
}
