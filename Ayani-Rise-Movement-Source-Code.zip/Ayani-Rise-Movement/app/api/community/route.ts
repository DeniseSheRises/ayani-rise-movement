import { apiError, bucket, db, jsonBody, libraryData, privateHeaders, requireAdmin, requireUser } from '../../../lib/community';
import { checkOrigin, CommunityError, meetLink, textField } from '../../../lib/community-policy';
export const dynamic = 'force-dynamic';

export async function GET() {
  try { return Response.json(await libraryData(), { headers: privateHeaders }); }
  catch (error) { return apiError(error); }
}
export async function POST(request: Request) {
  try {
    checkOrigin(request);
    const user = await requireUser();
    const data = await jsonBody(request);
    if (data.action === 'request-access') {
      await db().prepare("INSERT INTO community_members (user_id,email,name,status,created_at) VALUES (?,?,?,'pending',?) ON CONFLICT(user_id) DO UPDATE SET email = excluded.email, name = excluded.name").bind(user.userId, user.email, user.fullName || user.displayName, new Date().toISOString()).run();
    } else {
      await requireAdmin();
      if (data.action === 'member-status') {
        const id = textField(data.id, 'a member', 200);
        if (!['active', 'paused'].includes(String(data.status))) throw new CommunityError(400, 'Please choose a valid membership status.');
        await db().prepare('UPDATE community_members SET status = ? WHERE user_id = ?').bind(data.status, id).run();
      } else if (data.action === 'save-call') {
        const title = textField(data.title, 'a call title', 150);
        const description = textField(data.description, 'a description', 1200, false);
        const startsAt = textField(data.startsAt, 'a call date', 50);
        const date = new Date(startsAt);
        const duration = Number(data.durationMinutes);
        if (!Number.isFinite(date.getTime()) || !Number.isInteger(duration) || duration < 15 || duration > 240) throw new CommunityError(400, 'Please check the call date and duration.');
        const link = meetLink(data.meetUrl);
        await db().prepare('INSERT INTO community_calls (id,title,description,starts_at,duration_minutes,meet_url) VALUES (?,?,?,?,?,?)').bind(crypto.randomUUID(), title, description, date.toISOString(), duration, link).run();
      } else if (data.action === 'delete-call') {
        await db().prepare('DELETE FROM community_calls WHERE id = ?').bind(textField(data.id, 'a call', 100)).run();
      } else if (data.action === 'resource-visibility') {
        if (typeof data.published !== 'boolean') throw new CommunityError(400, 'Please choose a valid visibility.');
        await db().prepare('UPDATE community_resources SET published = ? WHERE id = ?').bind(data.published ? 1 : 0, textField(data.id, 'a resource', 100)).run();
      } else if (data.action === 'delete-resource') {
        const id = textField(data.id, 'a resource', 100);
        const resource = await db().prepare('SELECT file_key FROM community_resources WHERE id = ?').bind(id).first<{ file_key: string }>();
        if (!resource) throw new CommunityError(404, 'This resource was already removed.');
        await db().prepare('DELETE FROM community_resources WHERE id = ?').bind(id).run();
        await bucket().delete(resource.file_key);
      } else { throw new CommunityError(400, 'Unknown action.'); }
    }
    return Response.json({ ok: true }, { headers: privateHeaders });
  } catch (error) { return apiError(error); }
}
