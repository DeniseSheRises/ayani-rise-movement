'use client';
import { useEffect, useState } from 'react';
const links = [{href:'/#about',label:'Meet Denisa'},{href:'/#experiences',label:'Work with me'},{href:'/#gatherings',label:'Gatherings'},{href:'/community',label:'Community'},{href:'/return-to-her',label:'Retreats'}];
export default function HubNav() {
  const [open, setOpen] = useState(false);
  useEffect(()=>{
    if(!open) return;
    const closeOnEscape=(event:KeyboardEvent)=>{if(event.key==='Escape')setOpen(false);};
    window.addEventListener('keydown',closeOnEscape);
    return ()=>window.removeEventListener('keydown',closeOnEscape);
  },[open]);
  return <header className="hub-nav">
    <a className="hub-wordmark" href="/" aria-label="Ayani Rise Movement home"><span>AYANI RISE</span><small>M O V E M E N T</small></a>
    <button className="hub-menu-toggle" type="button" aria-expanded={open} aria-controls="hub-navigation" onClick={()=>setOpen(!open)}>{open?'Close':'Menu'} <span aria-hidden="true">{open?'−':'+'}</span></button>
    <nav id="hub-navigation" className={open?'is-open':''} aria-label="Main navigation">{links.map(l=><a key={l.href} href={l.href} onClick={()=>setOpen(false)}>{l.label}</a>)}<a className="hub-nav-cta" href="/#connect" onClick={()=>setOpen(false)}>Let’s connect <span aria-hidden="true">↗</span></a></nav>
  </header>;
}
