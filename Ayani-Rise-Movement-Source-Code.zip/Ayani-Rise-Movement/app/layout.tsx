import type { Metadata } from 'next';
import './retreat.css';
import './globals.css';
import './community.css';

export const metadata: Metadata = {
  title: 'Ayani Rise Movement | Denisa Wild',
  description: 'Come home to your body. Rise into your power. Feminine embodiment, dance, Kundalini activation and sisterhood with Denisa Wild. Toronto gatherings and global retreats.',
  openGraph: { title: 'Ayani Rise Movement · Denisa Wild', description: 'Feminine embodiment. Dance. Ritual. Sisterhood. From disconnected to wildly alive.', type: 'website', images: [{url: '/images/denisa-wild-reference.webp', alt: 'Denisa Wild by the water'}] },
  icons: { icon: '/favicon.svg' },
};

export default function RootLayout({children}: Readonly<{children: React.ReactNode}>) {
  return <html lang="en"><head>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;1,400;1,500&family=DM+Sans:wght@400;500;600&display=swap" />
    <link rel="stylesheet" href="https://fonts.cdnfonts.com/css/glacial-indifference-2" />
  </head><body>{children}</body></html>;
}
