import type { Metadata } from 'next';
import { libraryData } from '../../lib/community';
import { chatGPTSignInPath, chatGPTSignOutPath } from '../chatgpt-auth';
import MemberLibrary from './MemberLibrary';
export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'Member Library | Rise Sister Online', robots: { index: false, follow: false }, description: 'Your private home for Rise Sister Online recordings, live gatherings, and resources.' };
export default async function MembershipPage() {
  return <MemberLibrary initialData={await libraryData()} signInPath={chatGPTSignInPath('/membership')} signOutPath={chatGPTSignOutPath('/community')} />;
}
